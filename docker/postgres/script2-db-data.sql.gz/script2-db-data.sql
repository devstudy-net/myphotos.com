INSERT INTO profile (id, uid, email, first_name, last_name, avatar_url, job_title, "location", photo_count, created, rating)
VALUES (6, 'carla-walton', 'carla-walton@myphotos.com', 'Carla', 'Walton',
        '/media/avatar/166b9c32-6988-46a9-8c7f-fa87d4aa9970.jpg', 'Fullstack Developer', 'Los Angeles, California', 9,
        '2019-08-01 11:06:09.000', 53730)
     , (3, 'dinesh-chugtai', 'dinesh-chugtai@myphotos.com', 'Dinesh', 'Chugtai',
        '/media/avatar/882c1f6d-7dcf-4a09-8448-e75fabbfbd23.jpg', 'Senior Programmer', 'Los Angeles, California', 13,
        '2019-08-01 11:06:00.000', 92875)
     , (1, 'richard-hendricks', 'richard-hendricks@myphotos.com', 'Richard', 'Hendricks',
        '/media/avatar/49c54f1d-e0dc-4af8-a624-68c3fa38a13e.jpg', 'CEO of Pied Piper', 'Los Angeles, California', 7,
        '2019-08-01 11:05:52.000', 50915)
     , (4, 'bertram-gilfoyle', 'bertram-gilfoyle@myphotos.com', 'Bertram', 'Gilfoyle',
        '/media/avatar/349d7114-ec7f-4e1d-a1c0-1726e072e315.jpg', 'Senior Systems Architect', 'Los Angeles, California',
        9, '2019-08-01 11:06:04.000', 46275)
     , (2, 'jared-dunn', 'jared-dunn@myphotos.com', 'Jared', 'Dunn',
        '/media/avatar/eb19f197-98a1-4f9b-9a9b-ca6050331658.jpg', 'Head of Business Development',
        'Los Angeles, California', 13, '2019-08-01 11:05:56.000', 85435)
     , (5, 'erlich-bachmann', 'erlich-bachmann@myphotos.com', 'Erlich', 'Bachmann',
        '/media/avatar/e0d37caf-cf53-4173-871e-13f2071679b6.jpg', 'Majority Investor', 'Los Angeles, California', 5,
        '2019-08-01 11:06:07.000', 44925);

INSERT INTO photo (id, profile_id, small_url, large_url, original_url, "views", downloads, created)
VALUES (123456, 1, '/media/photo/058ede65-7d32-4555-bf6d-4c757749c0f3.jpg',
        '/media/photo/f0ca5ad7-fdc1-4a6a-bfe0-748328555d12.jpg', '51f4da6a-7d8f-4b7a-a937-47067a8bbf64.jpg', 2355, 87,
        '2019-08-01 11:05:53.000')
     , (123457, 1, '/media/photo/29f416f4-6c0b-44f0-9ede-07345f83ca1e.jpg',
        '/media/photo/ad2d5e0b-19c6-4abe-acf9-f6fbb4165aab.jpg', '07660200-64f7-4122-83ff-debeeac50694.jpg', 195, 71,
        '2019-08-01 11:05:54.000')
     , (123458, 1, '/media/photo/f3d52f7f-e7a8-4c61-b077-4f6923861dff.jpg',
        '/media/photo/b859a205-4813-416a-b92d-2072fe6c5d2c.jpg', '5684bd5f-9969-4aaa-9b2b-664f5d220608.jpg', 3350, 44,
        '2019-08-01 11:05:54.000')
     , (123459, 1, '/media/photo/a0f77616-425b-4990-9b14-214d83a48dbe.jpg',
        '/media/photo/b98b70b9-2c35-44e4-acd5-a3067b00e8ac.jpg', '6d1aedae-6814-4076-a756-b85d80cb5923.jpg', 1265, 42,
        '2019-08-01 11:05:55.000')
     , (123460, 1, '/media/photo/c4cf3845-2318-4de1-8926-eb0694e35835.jpg',
        '/media/photo/7cd723e8-269a-4e5d-954e-d97768911fcb.jpg', '86fde5ec-de26-46ef-bc68-5abbc00b0c49.jpg', 4580, 49,
        '2019-08-01 11:05:55.000')
     , (123461, 1, '/media/photo/5bb7e3ea-06ba-4acd-b62f-7098cb265ba1.jpg',
        '/media/photo/03efc953-5ed8-4ca8-bc99-e7acef55cb5b.jpg', 'ea96ddef-0c38-4f9e-a458-c4b8331ddca6.jpg', 840, 13,
        '2019-08-01 11:05:56.000')
     , (123462, 1, '/media/photo/b81e7be3-22f1-4421-b0bd-fd4cc51323ee.jpg',
        '/media/photo/ece4ba6a-3d5d-437f-a812-6092f024c58d.jpg', 'd5f3a10a-736f-4bd2-ba59-414d83ca2b5f.jpg', 3630, 41,
        '2019-08-01 11:05:56.000')
     , (123463, 2, '/media/photo/db1d83c9-45dc-4280-9cb7-1534c869ac7d.jpg',
        '/media/photo/65343cea-d510-4d86-a670-949418a5e671.jpg', '0aa68b22-75d0-4422-851d-8d27dd70322d.jpg', 1750, 86,
        '2019-08-01 11:05:56.000')
     , (123464, 2, '/media/photo/f28482e1-c910-49be-909f-a7d2b62d8792.jpg',
        '/media/photo/0c1bd090-0964-4d0e-be20-2291696dba24.jpg', '49683289-5db2-4ff8-add1-d58f4a392604.jpg', 4185, 15,
        '2019-08-01 11:05:56.000')
     , (123465, 2, '/media/photo/d0b40bda-7e50-448e-96e4-ce572f2fbad0.jpg',
        '/media/photo/d094f39b-d4c1-4e3b-a6e1-257ee4bcdfe4.jpg', '5e784e20-3599-4887-9569-e26ebef7bfd3.jpg', 4325, 3,
        '2019-08-01 11:05:57.000')
     , (123466, 2, '/media/photo/a0736148-2fdb-466d-9d93-42cf4411cfae.jpg',
        '/media/photo/42026ffb-b6b0-40d9-acb0-43fc1aecf06d.jpg', 'a88377f3-5d29-4c95-ade7-0e6a2be3285c.jpg', 2575, 24,
        '2019-08-01 11:05:57.000')
     , (123467, 2, '/media/photo/80ab5002-2df3-4b53-82fe-dae6a22e101f.jpg',
        '/media/photo/98b0c993-4927-4216-a97c-8e124bc3c1e5.jpg', '76aa654b-9f4b-474e-9130-32f8ac376d52.jpg', 1115, 4,
        '2019-08-01 11:05:57.000')
     , (123468, 2, '/media/photo/0733a4e5-295f-46b6-8188-a0fc2b2b1c2d.jpg',
        '/media/photo/94700597-1cce-4ca4-ab24-d1784acfe4a6.jpg', '24097041-220e-4d02-bc2e-f4b6cbae2c34.jpg', 1145, 5,
        '2019-08-01 11:05:57.000')
     , (123469, 2, '/media/photo/aafc6d68-4e1d-4340-a461-d2142353936c.jpg',
        '/media/photo/6b118831-a60e-445d-97fe-e94414de499c.jpg', '3c7378f5-f273-4674-93c7-c5512b76973a.jpg', 2605, 76,
        '2019-08-01 11:05:58.000')
     , (123470, 2, '/media/photo/b3137d81-ea53-46eb-b0d5-f1c864b84cd3.jpg',
        '/media/photo/0e788525-6697-4bc9-a9ce-bba487712782.jpg', '46def745-baff-4aa6-b903-1dff2ba3f117.jpg', 365, 32,
        '2019-08-01 11:05:58.000')
     , (123471, 2, '/media/photo/178b9e3b-2c99-43c2-b52c-77fee6112253.jpg',
        '/media/photo/f6d35bfa-543d-46ba-b194-e3df5e640a26.jpg', 'df2a09bf-90c3-41c9-af2b-e76da5466954.jpg', 2290, 80,
        '2019-08-01 11:05:58.000')
     , (123472, 2, '/media/photo/74a36900-4441-4c0e-9918-f691251cabef.jpg',
        '/media/photo/2437a16f-fbbe-4273-b7e2-8726dc2cc7a9.jpg', 'b3f06c6a-2b84-41ad-80e9-10229b0cae13.jpg', 105, 85,
        '2019-08-01 11:05:59.000')
     , (123473, 2, '/media/photo/105ecf0e-5b33-4c50-b01b-0bb94e74475a.jpg',
        '/media/photo/9320ab79-082a-4871-8f22-94e88ab46de7.jpg', 'f3af7598-d25b-4be3-bef0-60c7fdff87c3.jpg', 1310, 60,
        '2019-08-01 11:05:59.000')
     , (123474, 2, '/media/photo/654dd3b4-2c82-498f-8da3-8012a90b2fd2.jpg',
        '/media/photo/20b0bf92-fff5-4600-942b-25861a63c25a.jpg', '3b4a8a87-379f-4004-8625-4091224eaed4.jpg', 3205, 2,
        '2019-08-01 11:06:00.000')
     , (123475, 2, '/media/photo/744aea06-d75d-4ae4-afdd-e416dacf97c8.jpg',
        '/media/photo/db8f7810-1fa2-4008-aa66-ea06e96fa69a.jpg', 'd40f26a9-0841-4c82-8cb5-9f61a7fbad32.jpg', 4060, 92,
        '2019-08-01 11:06:00.000')
     , (123476, 3, '/media/photo/47d65e6b-e2e6-4a58-83cb-a1aa10aed7e8.jpg',
        '/media/photo/96b088b5-d597-495f-8678-de884070d08b.jpg', '631e4f53-489f-4919-acc4-be4ebacdb82c.jpg', 1175, 83,
        '2019-08-01 11:06:01.000')
     , (123477, 3, '/media/photo/0395c32d-a31d-4912-be8c-3dfc7bd89ff1.jpg',
        '/media/photo/9a637fb5-4906-49e3-9e67-f3286cea0f08.jpg', 'dfa93cc5-120d-49bc-94ba-6adcd96c76a9.jpg', 3770, 39,
        '2019-08-01 11:06:01.000')
     , (123478, 3, '/media/photo/067e400b-3bc6-48e1-ba02-c3cdb5f7d803.jpg',
        '/media/photo/f960ac05-26ed-4fbb-ae10-1d9250d0287b.jpg', '8ddb2f91-cd28-42f4-9062-a763075ce896.jpg', 1425, 17,
        '2019-08-01 11:06:01.000')
     , (123479, 3, '/media/photo/0ba09188-b1ce-4549-ae8d-03255b0990b0.jpg',
        '/media/photo/7c857302-2438-4590-aa14-54d17b1883f3.jpg', '7a0ded49-18c5-42aa-beff-e44daaa565a1.jpg', 175, 34,
        '2019-08-01 11:06:02.000')
     , (123480, 3, '/media/photo/20eb2f38-296c-4d1c-ad31-bb9b4f4d026e.jpg',
        '/media/photo/3c1e9870-46ac-419e-b19d-fa8f0a96bb4e.jpg', '6ed7ecd5-37cc-49a0-8d61-d8567e8d3953.jpg', 3345, 1,
        '2019-08-01 11:06:02.000')
     , (123481, 3, '/media/photo/c06ea8e6-5d6a-4286-b1df-d61f536e144c.jpg',
        '/media/photo/9dba0852-49b0-4f27-a245-97e6dadaa2a2.jpg', 'fd50e81c-8f93-476d-8a63-5fbc79a5140a.jpg', 2880, 71,
        '2019-08-01 11:06:02.000')
     , (123482, 3, '/media/photo/4c399e3a-d1be-45c4-980c-dd4c5c0f28f7.jpg',
        '/media/photo/b6c58f69-9dbe-4a63-9804-e3b96545299a.jpg', '3b017de2-39d5-48c4-ad3b-ad2148fb78c6.jpg', 4925, 73,
        '2019-08-01 11:06:03.000')
     , (123483, 3, '/media/photo/356a6cdb-5bf2-4e09-9ce2-3b6811b07872.jpg',
        '/media/photo/f6f129cc-437b-4aa7-af2c-19d81e28665a.jpg', '9274dc7a-01c5-4a30-b044-e99175b61338.jpg', 2520, 38,
        '2019-08-01 11:06:03.000')
     , (123484, 3, '/media/photo/567fe913-a467-4a9a-ac04-64fefc3a5945.jpg',
        '/media/photo/a245c213-22d3-458e-acb4-7031b112b62f.jpg', 'c8bf491d-f44f-4056-8b87-abdf08cf1fe5.jpg', 3780, 96,
        '2019-08-01 11:06:03.000')
     , (123485, 3, '/media/photo/e3bd844f-d028-4f80-b684-5e4ed85dd81d.jpg',
        '/media/photo/55742832-f6d5-48bf-8ed8-bc37ad39fa66.jpg', 'bd9a28fe-6bd9-4b49-835d-930c7eb7b9c1.jpg', 465, 73,
        '2019-08-01 11:06:03.000')
     , (123486, 3, '/media/photo/1b1ff556-5ea2-4fd7-a41f-47d5f8c24053.jpg',
        '/media/photo/17b919cb-ea4a-4e52-bace-286c7bbf4843.jpg', '743d1681-94ad-4fa1-8c72-cc9302bddb57.jpg', 1050, 43,
        '2019-08-01 11:06:04.000')
     , (123487, 3, '/media/photo/d96c5ced-92f9-4be7-bed6-b16ee5c35832.jpg',
        '/media/photo/57201ddd-f78d-4984-9999-db2802191d58.jpg', '109e4f94-96a0-4450-9037-a08a07112079.jpg', 3025, 33,
        '2019-08-01 11:06:04.000')
     , (123488, 3, '/media/photo/787fa4fe-ee4b-49e5-9309-9a0441812032.jpg',
        '/media/photo/260b87ab-ce8f-486f-968b-bc43f8c178d1.jpg', '6e481f92-d353-4c39-813b-5374e5e48ba5.jpg', 2940, 13,
        '2019-08-01 11:06:04.000')
     , (123489, 4, '/media/photo/b1fcfe22-ac9d-49a3-80e4-ddd460bdf861.jpg',
        '/media/photo/d4ede53e-1c11-42b4-95ab-6368122f7863.jpg', '995c7b22-00df-47fa-b6ee-4284d3aeb859.jpg', 2645, 21,
        '2019-08-01 11:06:05.000')
     , (123490, 4, '/media/photo/17bde37c-cf18-4e0b-9d5d-5512b24b733d.jpg',
        '/media/photo/e2acde0e-c199-48ff-9d18-a057d918b8fc.jpg', 'd6c7f463-9e1a-4ff8-977c-1900421e23d9.jpg', 2360, 55,
        '2019-08-01 11:06:05.000')
     , (123491, 4, '/media/photo/99402d34-c2a9-4fc8-b940-7cd0ff70aa1a.jpg',
        '/media/photo/bf00d875-899c-4cd0-9a45-487015d447c7.jpg', '1cc7a4b8-350f-4246-bd62-42e410820dd6.jpg', 1270, 46,
        '2019-08-01 11:06:06.000')
     , (123492, 4, '/media/photo/685c2e47-a7a2-4f45-9de5-67e0f0974b7a.jpg',
        '/media/photo/e272016e-70f0-4b0a-9819-0c3168b0e9ac.jpg', '7e5fd923-bac2-4c50-b95f-eae5606eb7ea.jpg', 960, 0,
        '2019-08-01 11:06:06.000')
     , (123493, 4, '/media/photo/f02a2838-1b2d-45aa-b3a5-77ba25a642c4.jpg',
        '/media/photo/6d9dc5f0-c4e6-4050-821f-da45bd104dea.jpg', 'd8433f4a-152b-4c8b-a0e0-ccd86b69f5c9.jpg', 1625, 25,
        '2019-08-01 11:06:06.000')
     , (123494, 4, '/media/photo/010c467a-ee8f-4af0-b03b-c75810fe7c5e.jpg',
        '/media/photo/5e451800-44de-49d3-85b7-4cebe142c5b9.jpg', 'a3846f42-77c0-4961-ace4-b5f582e6f9ad.jpg', 4745, 84,
        '2019-08-01 11:06:06.000')
     , (123495, 4, '/media/photo/56111f9e-f352-42e5-900e-89fe1f6e94ce.jpg',
        '/media/photo/1173663b-fa05-4674-ac52-9ede2190d452.jpg', '1e42e17b-c356-4b36-8f35-1cc9aae65b4a.jpg', 3285, 4,
        '2019-08-01 11:06:07.000')
     , (123496, 4, '/media/photo/f42fc43c-c281-4423-ba7e-50444ff8d593.jpg',
        '/media/photo/82765fe7-4bc2-4a06-90ec-5bd8e7eb4fd6.jpg', '00f31900-24e9-4581-bc66-3fbbf60f5ab9.jpg', 1440, 4,
        '2019-08-01 11:06:07.000')
     , (123497, 4, '/media/photo/92ffd9d0-c5a8-4c33-94ba-6c1368fa0f5e.jpg',
        '/media/photo/a06212d0-5b6d-4234-a345-0d8d5583d2d4.jpg', '2c56c9c5-aeb2-489d-a96e-0f97ea19e1ff.jpg', 1545, 25,
        '2019-08-01 11:06:07.000')
     , (123498, 5, '/media/photo/3caf7d08-88cd-41e4-9b31-0db69fda9726.jpg',
        '/media/photo/a9cce7f8-fb7b-43b5-aaa8-f1de267c9ea1.jpg', 'e886b10b-7cd2-4130-b380-eb820a32c20e.jpg', 3900, 75,
        '2019-08-01 11:06:08.000')
     , (123499, 5, '/media/photo/b12fc5f2-0e23-477b-84d3-cee0cee55f5f.jpg',
        '/media/photo/189fe8a4-01dd-4dda-808f-4d6f12a98f88.jpg', 'f9cae427-cdf3-46de-86bc-d3d2457fe9e8.jpg', 4075, 50,
        '2019-08-01 11:06:08.000')
     , (123500, 5, '/media/photo/2f51f29d-c153-4dc2-ad2a-f1da8e617c0c.jpg',
        '/media/photo/5ce9055f-598b-4f56-a6c4-434291d0d0de.jpg', 'ba89dc9b-e8f7-46fe-ad3a-4ef540f3eb35.jpg', 1380, 73,
        '2019-08-01 11:06:08.000')
     , (123501, 5, '/media/photo/cd0512a7-ebd1-4cf1-86ce-c95cc7b740bd.jpg',
        '/media/photo/2555546c-e410-43cd-aefb-c7965661e460.jpg', '6eaba085-6d5a-4793-a68b-eb259f5f2228.jpg', 4985, 37,
        '2019-08-01 11:06:08.000')
     , (123502, 5, '/media/photo/68616e6f-589c-4b5d-90fc-4bddc1a2ab66.jpg',
        '/media/photo/454f2867-9c2c-4306-9f66-3febf8e1b86e.jpg', '3017954b-6e16-40d5-93a4-ba21938873aa.jpg', 2785, 43,
        '2019-08-01 11:06:09.000')
     , (123503, 6, '/media/photo/1a4a40f6-9988-4de2-85c0-b8c1b876b038.jpg',
        '/media/photo/c34c18c3-fde3-4656-8c7d-7734a11643de.jpg', '39f38634-6339-4751-886e-9db2472d75c1.jpg', 730, 65,
        '2019-08-01 11:06:09.000')
     , (123504, 6, '/media/photo/ad65e208-fff9-48e3-9631-eb45492fd4df.jpg',
        '/media/photo/e0f798bc-1fe1-4ffb-9ea3-cbdeea6e6e37.jpg', '9c52dab5-b88d-483d-bdb8-12b6198420db.jpg', 3235, 67,
        '2019-08-01 11:06:10.000')
     , (123505, 6, '/media/photo/ca556c78-9dd7-42f0-8381-2f95d90886c0.jpg',
        '/media/photo/621a1a9e-dbf4-449d-b68c-d699b7b36de0.jpg', '02344bf8-07b7-4140-b173-70720d49539b.jpg', 665, 9,
        '2019-08-01 11:06:10.000')
     , (123506, 6, '/media/photo/00015ee8-6347-4c4c-8947-e0c408b7efe1.jpg',
        '/media/photo/899d183e-f5ab-4fc0-8175-187a00e7feac.jpg', '181f44f1-c696-4556-88b0-dcd6dc809804.jpg', 505, 70,
        '2019-08-01 11:06:11.000')
     , (123507, 6, '/media/photo/7dfd5a1d-cd80-4bf0-9482-22b5b74e9071.jpg',
        '/media/photo/0089817c-dee2-4b09-b9cb-4cc0a52a8c11.jpg', '57876d6e-f489-48b5-a437-72afda307d62.jpg', 475, 17,
        '2019-08-01 11:06:11.000')
     , (123508, 6, '/media/photo/62bd0629-b4a6-4a41-b2a7-7798ed515e3b.jpg',
        '/media/photo/99a88b2c-a599-4f24-a518-8d9d691153b4.jpg', 'a25274f9-1870-484a-977c-dfadbf20a06b.jpg', 2110, 21,
        '2019-08-01 11:06:11.000')
     , (123509, 6, '/media/photo/db90d95a-cd08-4686-a7ed-847aebed2383.jpg',
        '/media/photo/0d53aed4-9726-441c-a15a-9153184109e8.jpg', '8216f293-7c70-42dc-832a-a54b314183de.jpg', 4875, 44,
        '2019-08-01 11:06:12.000')
     , (123510, 6, '/media/photo/7efd0ed4-5949-4bdf-a999-09c067d542d6.jpg',
        '/media/photo/216d9513-9d5c-478d-ab0d-1f88594e4cd5.jpg', '4ecb79e2-3236-4899-b693-6b664ea8b0a4.jpg', 3600, 34,
        '2019-08-01 11:06:12.000')
     , (123511, 6, '/media/photo/de715ee5-9c80-4c7c-832b-b0fff49f4b6d.jpg',
        '/media/photo/c37957c2-700f-445f-8733-896a5370d98e.jpg', '16bbe3fd-6dfa-437c-891e-a49b392c4fbd.jpg', 1335, 35,
        '2019-08-01 11:06:12.000');

SELECT setval('photo_seq', 123512, false);
SELECT setval('profile_seq', 7, false);